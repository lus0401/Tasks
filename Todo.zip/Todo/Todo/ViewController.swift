//
//  ViewController.swift
//  Todo
//
//  Created by t2023-m0051 on 1/11/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var todos : [Todo] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        loadTodos()
    }
}

extension ViewController : UITableViewDataSource, UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todos.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TodoCell", for: indexPath)

        let todo = todos[indexPath.row]
        cell.textLabel?.text = todo.title
        cell.detailTextLabel?.text = todo.category
        cell.accessoryType = todo.isCompleted ? .checkmark : .none

        // Apply strikethrough effect if todo is completed
        let attributes: [NSAttributedString.Key: Any] = todo.isCompleted
            ? [NSAttributedString.Key.strikethroughStyle: NSUnderlineStyle.single.rawValue,
               NSAttributedString.Key.foregroundColor: UIColor.lightGray]
            : [:]
        cell.textLabel?.attributedText = NSAttributedString(string: todo.title, attributes: attributes)

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           // Toggle the completion status of the selected todo
           todos[indexPath.row].isCompleted.toggle()

           // Save updated todos to UserDefaults
           saveTodos()

           // Reload the table view
           tableView.reloadRows(at: [indexPath], with: .automatic)
       }

       func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
           // Handle swipe to delete
           if editingStyle == .delete {
               todos.remove(at: indexPath.row)

               // Save updated todos to UserDefaults
               saveTodos()

               // Reload the table view
               tableView.deleteRows(at: [indexPath], with: .automatic)
           }
       }

       // MARK: - Actions

       @IBAction func addTodoButtonTapped(_ sender: Any) {
           // Show alert to get user input
           showAddTodoAlert()
       }
    
    
    // MARK: - Private Functions

    private func showAddTodoAlert() {
        let alertController = UIAlertController(title: "Add Todo", message: nil, preferredStyle: .alert)

        alertController.addTextField { (titleTextField) in
            titleTextField.placeholder = "Title"
        }

        alertController.addTextField { (categoryTextField) in
            categoryTextField.placeholder = "Category"
        }

        let addAction = UIAlertAction(title: "Add", style: .default) { (_) in
            // Get user input
            guard let title = alertController.textFields?[0].text, !title.isEmpty,
                  let category = alertController.textFields?[1].text else {
                return
            }

            // Create a new todo
            let newTodo = Todo(id: UUID(), category: category, title: title, isCompleted: false)

            // Add the new todo to the array
            self.todos.append(newTodo)

            // Save updated todos to UserDefaults
            self.saveTodos()

            // Reload the table view
            self.tableView.reloadData()
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)

        alertController.addAction(addAction)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }
    
    private func saveTodos() {
        // Save todos to UserDefaults
        let todoData = try? JSONEncoder().encode(todos)
        UserDefaults.standard.set(todoData, forKey: "todos")
        //UserDefaults.standard.synchronize()
    }

    private func loadTodos() {
        // Load todos from UserDefaults
        if let todoData = UserDefaults.standard.data(forKey: "todos"),
           let savedTodos = try? JSONDecoder().decode([Todo].self, from: todoData) {
            todos = savedTodos
            tableView.reloadData()
       
        }
    }

}
