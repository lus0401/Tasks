//
//  Todo.swift
//  Todo
//
//  Created by t2023-m0051 on 1/11/24.
//

import Foundation

struct Todo : Codable {
    var id: UUID
    var category: String
    var title: String
    var isCompleted: Bool
}
